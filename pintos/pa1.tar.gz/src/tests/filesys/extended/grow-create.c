/* Create a file of size 0. */

#define TEST_SIZE 0
#include "tests/filesys/create.inc"
